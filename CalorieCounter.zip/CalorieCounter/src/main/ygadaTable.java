package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.sun.corba.se.pept.transport.Connection;

public class ygadaTable extends JFrame implements ActionListener{
	
	JPanel panelTable, panelField, panelButton, panelContainer, panelTitle, panelInput,panelTabel, panelokButton;
	JLabel titlelbl, sarapanlbl, sianglbl, malamlbl;
	JTextField srpanField, siangField, malamField;
	JButton oke;
	JScrollPane pane;
	tampilanAkhir talak;
	JDesktopPane content = new JDesktopPane();
	
	Vector<Vector<Object>> tableContent = new Vector<>();
	Vector<Object> tableRow, tableHeader;
	
	JTable table;
	DefaultTableModel dtm;
	public int kalori;
	
	Connect con = new Connect();
	
	public ygadaTable(int kalori) {
		this.kalori = kalori;
		tableHeader = new Vector<>();
		
		tableHeader.add("Makanan");
		tableHeader.add("Kalori");
		
		addData("1. Bubur Ayam", 201);
		addData("2. Nasi Goreng", 163);
		addData("3. Nasi Uduk", 290);
		addData("4. Burger", 294);
		addData("5. Bakso", 325);
		addData("6. Mie Instan", 528);
		addData("7. Ketoprak", 402);
		addData("8. Nasi + Ayam Geprek", 616);
		addData("9. Nasi + Soto", 596);
		addData("10. Baso Aci", 325);
		
		dtm = new DefaultTableModel(tableContent, tableHeader);
		table = new JTable(dtm);
		pane = new JScrollPane(table);
		
		titlelbl = new JLabel ("Masukan Nomer Makanan yang Kamu Makan !");
		sarapanlbl = new JLabel("Masukan Menu Sarapan");
		sianglbl = new JLabel("Masukan Menu Makan Siang");
		malamlbl = new JLabel("Masukan Menu Makan Malam");
		
		srpanField = new JTextField();
		siangField = new JTextField();
		malamField = new JTextField();
		
		panelTitle = new JPanel();
		panelTable = new JPanel();
		panelField = new JPanel(new GridLayout(3, 3));
		panelButton = new JPanel();
		panelInput = new JPanel(new GridLayout(2, 1));
		
		oke = new JButton("OK");
		oke.setBackground(new Color(0,0,0));
		oke.setForeground(new Color(255,255,255));
		
		panelTable.add(pane);
		
		panelTitle.add(titlelbl);
		panelField.add(sarapanlbl);
		panelField.add(srpanField);
		panelField.add(sianglbl);
		panelField.add(siangField);
		panelField.add(malamlbl);
		panelField.add(malamField);
		panelButton.add(oke);
		
		panelInput.add(panelTable);
		panelInput.add(panelField);
		
		panelContainer = new JPanel(new BorderLayout());
		
		panelContainer.add(panelTitle, BorderLayout.NORTH);
		panelContainer.add(panelInput, BorderLayout.CENTER);
		panelContainer.add(panelButton, BorderLayout.SOUTH);
		
		
		add(panelContainer);
		//setLayout(new BorderLayout());
		
		oke.addActionListener(this);
		
		setSize(500, 500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Calorie Counter");
		setResizable(true);
		setVisible(true);
	}
	
	public void addData(String makanan, int kalori){
		tableRow = new Vector<>();
		tableRow.add(makanan);
		tableRow.add(kalori);

		tableContent.add(tableRow);
	}
	
	
	


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== oke ) {
		
			int r = JOptionPane.showConfirmDialog(this, "Apakah anda yakin dengan makanan yang anda masukan ?", "Warning", JOptionPane.YES_NO_OPTION);
			if(r == JOptionPane.YES_OPTION){
				String srp = srpanField.getText().trim();
				String sng = siangField.getText().trim();
				String mlm = malamField.getText().trim();
				
				con.addKalori(kalori, total2.getText());
				
				talak = new tampilanAkhir(kalori, srp, sng, mlm);
				dispose();
			}
		}
}
}
	
		

