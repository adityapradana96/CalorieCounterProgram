package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class tampilanAkhir extends JFrame implements ActionListener{
	
	public JLabel hasil, kalkulasi,sisa;
	public JButton okbutton;
	inputKalori inputk;
	JFrame f;
	int srp1 = 0, sng1 = 0, mlm1 = 0;
	int total = 0;
	
	JDesktopPane content = new JDesktopPane();
	
	public int kalori;
	String srp;
	String sng;
	String mlm;
	int total2 = 0;
	
	
	public void show(){
		JFrame.isDefaultLookAndFeelDecorated();
		f = new JFrame("Calorie Input");
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		f.getContentPane().add(hasil);
		f.getContentPane().add(kalkulasi);
		f.getContentPane().add(sisa);
		f.getContentPane().add(okbutton);
		
		f.setBounds(0,0,410,200);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
			
		}
		
		public void generate(){
			okbutton.addActionListener(this);	
		}
	
	public tampilanAkhir(int kalori, String srp, String sng, String mlm) {
		this.kalori = kalori;
		this.srp = srp;
		this.sng = sng;
		this.mlm = mlm;

		Calculation();
		hasil = new JLabel("Jumlah Kalori yang Anda Makan : " + total);
		hasil.setLocation(100,30);
		hasil.setSize(hasil.getPreferredSize());
		
		kalkulasi = new JLabel ();
		kalkulasi.setLocation(180,50);
		kalkulasi.setSize(kalkulasi.getPreferredSize());
		
		sisa = new JLabel ("\nAnda Menyisakan " + total2 + " Kalori untuk Hari Ini" );
		sisa.setLocation(80,70);
		sisa.setSize(sisa.getPreferredSize());
		
		

		okbutton = new JButton("OK");
		okbutton.setBackground(new Color(0,0,0));
		okbutton.setForeground(new Color(255,255,255));
		okbutton.setLocation(175,100);
		okbutton.setSize(okbutton.getPreferredSize());
		generate();
		okbutton.addActionListener(this);
		
		show();
	}
	
	public void Calculation() {
		
	//	int result = Integer.parseInt(kalori);
			
		int srp2 = Integer.parseInt(srp);
		
		int sng2 = Integer.parseInt(sng);
		
		int mlm2 = Integer.parseInt(mlm);
		
		
		if(srp2 == 1) {
			srp1 = 201;
		} else if (srp2 == 2){
			srp1 = 163;
		} else if (srp2 == 3){
			srp1 = 290;
		} else if (srp2 == 4){
			srp1 = 294;
		} else if (srp2 == 5){
			srp1 = 325;
		} else if (srp2 == 6){
			srp1 = 528;
		} else if (srp2 == 7){
			srp1 = 402;
		} else if (srp2 == 8){
			srp1 = 616;
		} else if (srp2 == 9){
			srp1 = 596;
		} else if (srp2 == 10){
			srp1 = 325;
		}
		
		if(sng2 == 1) {
			sng1 = 201;
		} else if (sng2 == 2){
			sng1 = 163;
		} else if (sng2 == 3){
			sng1 = 290;
		} else if (sng2 == 4){
			sng1 = 294;
		} else if (sng2 == 5){
			sng1 = 325;
		} else if (sng2 == 6){
			sng1 = 528;
		} else if (sng2 == 7){
			sng1 = 402;
		} else if (sng2 == 8){
			sng1 = 616;
		} else if (sng2 == 9){
			sng1 = 596;
		} else if (sng2 == 10){
			sng1 = 325;
		}
		
		if(mlm2 == 1) {
			mlm1 = 201;
		} else if (mlm2 == 2){
			mlm1 = 163;
		} else if (mlm2 == 3){
			mlm1 = 290;
		} else if (mlm2 == 4){
			mlm1 = 294;
		} else if (mlm2 == 5){
			mlm1 = 325;
		} else if (mlm2 == 6){
			mlm1 = 528;
		} else if (mlm2 == 7){
			mlm1 = 402;
		} else if (mlm2 == 8){
			mlm1 = 616;
		} else if (mlm2 == 9){
			mlm1 = 596;
		} else if (mlm2 == 10){
			mlm1 = 325;
		}
		
		total = srp1 + sng1 + mlm1 ;
		total2 = kalori - total;
		
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == okbutton){
			
			inputk = new inputKalori();
			f.dispose();
		}
	}

}
