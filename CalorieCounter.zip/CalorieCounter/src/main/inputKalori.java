package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class inputKalori extends JFrame implements ActionListener{
	public JLabel jmlhkalori;
	public JTextField kalori;
	public JButton okbutton;
	ygadaTable ygtable;
	JDesktopPane content = new JDesktopPane();
	JFrame f;
	
	public inputKalori() {
		jmlhkalori = new JLabel("Masukan Jumlah Kalori (Standard 2000) : ");
		jmlhkalori.setLocation(20, 30);
		jmlhkalori.setSize(jmlhkalori.getPreferredSize());

		kalori = new JTextField(10);
		kalori.setLocation(260, 30);
		kalori.setSize(kalori.getPreferredSize());

		okbutton = new JButton("OK");
		okbutton.setBackground(new Color(0, 0, 0));
		okbutton.setForeground(new Color(255, 255, 255));
		okbutton.setLocation(260, 60);
		okbutton.setSize(okbutton.getPreferredSize());

		JFrame.isDefaultLookAndFeelDecorated();
		f = new JFrame("Calorie Input");
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		okbutton.addActionListener(this);	
		
		f.getContentPane().add(jmlhkalori);
		f.getContentPane().add(kalori);
		f.getContentPane().add(okbutton);

		f.setBounds(0, 0, 410, 200);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}

	public static void main(String [] args) {
		new inputKalori();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
				if(e.getSource() == okbutton) {
					f.dispose();
					String d = kalori.getText().trim();
					int dd = Integer.parseInt(d);
					
					ygtable = new ygadaTable(dd);

				}
			}
	}


	